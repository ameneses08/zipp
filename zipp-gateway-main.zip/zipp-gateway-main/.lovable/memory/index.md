# Project Memory

## Core
Zipp: cross-border payments for LATAM importers buying from EU/US suppliers. 7 screens total.
Mercury/Notion aesthetic. Inter for ALL UI text (no serif in app). Teal (#0F9D8A) + off-white.
Primary: teal 174 62% 38%. Background: warm off-white 40 20% 97%.
Left sidebar nav with Zipp logo, company "Agroinnova S.A." at bottom.
