import { createContext, useContext, useState, ReactNode, useCallback } from "react";
import { Invoice, mockInvoices } from "./invoices";

interface InvoiceContextValue {
  invoices: Invoice[];
  addInvoice: (invoice: Omit<Invoice, "id">) => string;
  markPaid: (id: string) => void;
}

const InvoiceContext = createContext<InvoiceContextValue | null>(null);

export function InvoiceProvider({ children }: { children: ReactNode }) {
  const [invoices, setInvoices] = useState<Invoice[]>(mockInvoices);

  const addInvoice = useCallback((data: Omit<Invoice, "id">) => {
    const id = crypto.randomUUID();
    const invoice: Invoice = { ...data, id };
    setInvoices((prev) => [invoice, ...prev]);
    return id;
  }, []);

  const markPaid = useCallback((id: string) => {
    setInvoices((prev) =>
      prev.map((inv) =>
        inv.id === id
          ? { ...inv, status: "paid" as const, paidDate: new Date().toISOString().split("T")[0] }
          : inv
      )
    );
  }, []);

  return (
    <InvoiceContext.Provider value={{ invoices, addInvoice, markPaid }}>
      {children}
    </InvoiceContext.Provider>
  );
}

export function useInvoices() {
  const ctx = useContext(InvoiceContext);
  if (!ctx) throw new Error("useInvoices must be used within InvoiceProvider");
  return ctx;
}
