export type InvoiceStatus = "pending" | "due_soon" | "overdue" | "paid";

export interface Invoice {
  id: string;
  supplierName: string;
  invoiceNumber: string;
  amount: number;
  currency: string;
  dueDate: string;
  status: InvoiceStatus;
  iban?: string;
  bic?: string;
  paidDate?: string;
}

export const mockInvoices: Invoice[] = [
  {
    id: "1",
    supplierName: "Luxembourg Industries Ltd.",
    invoiceNumber: "INV-2026-0871",
    amount: 60388,
    currency: "USD",
    dueDate: "2026-09-07",
    status: "pending",
    iban: "LU28 0019 4006 4475 0000",
    bic: "BCEELULL",
  },
  {
    id: "2",
    supplierName: "Schmidt Maschinenbau GmbH",
    invoiceNumber: "INV-2026-0902",
    amount: 12450,
    currency: "EUR",
    dueDate: "2026-03-25",
    status: "overdue",
    iban: "DE89 3704 0044 0532 0130 00",
    bic: "COBADEFFXXX",
  },
  {
    id: "3",
    supplierName: "Olivetti Forniture S.r.l.",
    invoiceNumber: "INV-2026-0915",
    amount: 5069.4,
    currency: "EUR",
    dueDate: "2026-03-28",
    status: "due_soon",
    iban: "IT60 X054 2811 1010 0000 0123 456",
    bic: "BPPIITRRXXX",
  },
  {
    id: "4",
    supplierName: "Dubois et Fils SARL",
    invoiceNumber: "INV-2026-0933",
    amount: 8200,
    currency: "EUR",
    dueDate: "2026-04-01",
    status: "due_soon",
    iban: "FR76 3000 6000 0112 3456 7890 189",
    bic: "AGRIFRPP",
  },
  {
    id: "5",
    supplierName: "Van der Berg Logistics BV",
    invoiceNumber: "INV-2026-0780",
    amount: 3150.75,
    currency: "EUR",
    dueDate: "2026-04-22",
    status: "pending",
    iban: "NL91 ABNA 0417 1643 00",
    bic: "ABNANL2A",
  },
  {
    id: "6",
    supplierName: "Whitfield Industrial Supplies Ltd",
    invoiceNumber: "INV-2026-0744",
    amount: 6800,
    currency: "GBP",
    dueDate: "2026-03-13",
    status: "paid",
    paidDate: "2026-03-12",
    iban: "GB29 NWBK 6016 1331 9268 19",
    bic: "NWBKGB2L",
  },
];

export function getDashboardSummary(invoices: Invoice[]) {
  const byStatus = (s: InvoiceStatus) => invoices.filter((i) => i.status === s);
  const sumAmount = (list: Invoice[]) => list.reduce((sum, i) => sum + i.amount, 0);

  const pending = byStatus("pending");
  const dueSoon = byStatus("due_soon");
  const overdue = byStatus("overdue");
  const paid = byStatus("paid");

  return {
    totalPending: pending.length,
    pendingAmount: sumAmount(pending),
    dueSoon: dueSoon.length,
    dueSoonAmount: sumAmount(dueSoon),
    overdue: overdue.length,
    overdueAmount: sumAmount(overdue),
    paid: paid.length,
    paidAmount: sumAmount(paid),
  };
}

export function formatCurrency(amount: number, currency: string) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency }).format(amount);
}

export function getStatusBadgeVariant(status: InvoiceStatus) {
  const map: Record<InvoiceStatus, "pending" | "dueSoon" | "overdue" | "paid"> = {
    pending: "pending",
    due_soon: "dueSoon",
    overdue: "overdue",
    paid: "paid",
  };
  return map[status];
}

export function getStatusLabel(status: InvoiceStatus) {
  const map: Record<InvoiceStatus, string> = {
    pending: "Pending",
    due_soon: "Due soon",
    overdue: "Overdue",
    paid: "Paid",
  };
  return map[status];
}
