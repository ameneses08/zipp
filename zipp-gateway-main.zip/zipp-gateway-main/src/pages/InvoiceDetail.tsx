import { useNavigate, useParams } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  formatCurrency, getStatusBadgeVariant, getStatusLabel,
} from "@/lib/invoices";
import { useInvoices } from "@/lib/InvoiceContext";
import { ArrowLeft, Send } from "lucide-react";

const InvoiceDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { invoices } = useInvoices();
  const invoice = invoices.find((i) => i.id === id);

  if (!invoice) {
    return (
      <AppLayout>
        <p className="text-muted-foreground">Invoice not found.</p>
      </AppLayout>
    );
  }

  const canPay = invoice.status !== "paid";

  return (
    <AppLayout>
      <div className="mx-auto max-w-lg space-y-6">
        <button
          onClick={() => navigate("/dashboard")}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4" /> Back to invoices
        </button>

        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-foreground">{invoice.supplierName}</h1>
          <Badge variant={getStatusBadgeVariant(invoice.status)}>
            {getStatusLabel(invoice.status)}
          </Badge>
        </div>

        <div className="rounded-lg border border-border bg-card p-6 space-y-4">
          <Row label="Invoice number" value={invoice.invoiceNumber} />
          <Row label="Amount" value={formatCurrency(invoice.amount, invoice.currency)} />
          <Row label="Currency" value={invoice.currency} />
          <Row label="Due date" value={new Date(invoice.dueDate).toLocaleDateString("en-US", {
            month: "long", day: "numeric", year: "numeric",
          })} />
          {invoice.iban && <Row label="IBAN" value={invoice.iban} />}
          {invoice.bic && <Row label="BIC / SWIFT" value={invoice.bic} />}
        </div>

        {canPay && (
          <Button className="w-full gap-2" onClick={() => navigate(`/pay/${invoice.id}`)}>
            <Send className="h-4 w-4" />
            Pay now
          </Button>
        )}
      </div>
    </AppLayout>
  );
};

const Row = ({ label, value }: { label: string; value: string }) => (
  <div className="flex items-center justify-between">
    <span className="text-sm text-muted-foreground">{label}</span>
    <span className="text-sm text-foreground font-medium">{value}</span>
  </div>
);

export default InvoiceDetail;
