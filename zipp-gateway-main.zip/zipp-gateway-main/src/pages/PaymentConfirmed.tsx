import { useNavigate, useParams } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/invoices";
import { useInvoices } from "@/lib/InvoiceContext";
import { CheckCircle } from "lucide-react";

const PaymentConfirmed = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { invoices } = useInvoices();
  const invoice = invoices.find((i) => i.id === id);

  if (!invoice) {
    return (
      <AppLayout>
        <p className="text-muted-foreground">Invoice not found.</p>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="mx-auto max-w-md flex flex-col items-center justify-center py-20 space-y-6 text-center">
        <div className="h-16 w-16 rounded-full bg-[hsl(var(--status-paid-bg))] flex items-center justify-center">
          <CheckCircle className="h-8 w-8 text-[hsl(var(--status-paid-text))]" />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl font-semibold text-foreground">Payment sent</h1>
          <p className="text-sm text-muted-foreground leading-relaxed max-w-sm">
            {invoice.supplierName} will receive{" "}
            <span className="font-semibold text-foreground">
              {formatCurrency(invoice.amount, invoice.currency)}
            </span>{" "}
            within minutes.
          </p>
        </div>

        <Button variant="outline" onClick={() => navigate("/dashboard")} className="mt-4">
          Back to dashboard
        </Button>
      </div>
    </AppLayout>
  );
};

export default PaymentConfirmed;
