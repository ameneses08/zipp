import { useNavigate, useParams } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/invoices";
import { useInvoices } from "@/lib/InvoiceContext";
import { ArrowLeft, Send } from "lucide-react";

const PayInvoice = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { invoices, markPaid } = useInvoices();
  const invoice = invoices.find((i) => i.id === id);

  if (!invoice) {
    return (
      <AppLayout>
        <p className="text-muted-foreground">Invoice not found.</p>
      </AppLayout>
    );
  }

  const handleConfirm = () => {
    markPaid(invoice.id);
    navigate(`/payment-confirmed/${invoice.id}`);
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-md space-y-6">
        <button
          onClick={() => navigate(-1 as any)}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>

        <div>
          <h1 className="text-2xl font-semibold text-foreground">Pay invoice</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Confirm the payment details below
          </p>
        </div>

        <div className="rounded-lg border border-border bg-card p-6 space-y-4">
          <Row label="Supplier" value={invoice.supplierName} />
          <Row label="Invoice" value={invoice.invoiceNumber} />
          <Row label="Amount" value={formatCurrency(invoice.amount, invoice.currency)} highlight />
          <Row label="Due date" value={new Date(invoice.dueDate).toLocaleDateString("en-US", {
            month: "long", day: "numeric", year: "numeric",
          })} />
        </div>

        <div className="rounded-lg border border-primary/20 bg-primary/5 p-5">
          <p className="text-sm text-foreground text-center">
            Send <span className="font-semibold">{formatCurrency(invoice.amount, invoice.currency)}</span> to{" "}
            <span className="font-semibold">{invoice.supplierName}</span>?
          </p>
        </div>

        <div className="flex gap-3">
          <Button variant="outline" className="flex-1" onClick={() => navigate("/dashboard")}>
            Cancel
          </Button>
          <Button className="flex-1 gap-2" onClick={handleConfirm}>
            <Send className="h-4 w-4" />
            Confirm payment
          </Button>
        </div>
      </div>
    </AppLayout>
  );
};

const Row = ({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) => (
  <div className="flex items-center justify-between">
    <span className="text-sm text-muted-foreground">{label}</span>
    <span className={`text-sm ${highlight ? "font-semibold text-foreground" : "text-foreground"}`}>
      {value}
    </span>
  </div>
);

export default PayInvoice;
