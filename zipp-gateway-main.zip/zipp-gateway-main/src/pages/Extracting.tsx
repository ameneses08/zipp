import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import { Progress } from "@/components/ui/progress";
import { FileText } from "lucide-react";

const steps = [
  "Reading invoice...",
  "Extracting fields...",
  "Validating data...",
];

const Extracting = () => {
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + 2;
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(() => navigate("/review"), 400);
          return 100;
        }
        if (next > 66) setStepIndex(2);
        else if (next > 33) setStepIndex(1);
        return next;
      });
    }, 60);
    return () => clearInterval(interval);
  }, [navigate]);

  return (
    <AppLayout>
      <div className="mx-auto max-w-md flex flex-col items-center justify-center py-24 space-y-8">
        <div className="relative">
          <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center">
            <FileText className="h-8 w-8 text-primary animate-pulse" />
          </div>
        </div>

        <div className="text-center space-y-2">
          <h2 className="text-xl font-semibold text-foreground">{steps[stepIndex]}</h2>
          <p className="text-sm text-muted-foreground">
            This usually takes a few seconds
          </p>
        </div>

        <Progress value={progress} className="w-full h-2" />

        <p className="text-xs text-muted-foreground">{progress}%</p>
      </div>
    </AppLayout>
  );
};

export default Extracting;
