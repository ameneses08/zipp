import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  getDashboardSummary, formatCurrency,
  getStatusBadgeVariant, getStatusLabel, type InvoiceStatus,
} from "@/lib/invoices";
import { useInvoices } from "@/lib/InvoiceContext";
import { Upload, Clock, AlertTriangle, AlertCircle, CheckCircle, ChevronRight, Search } from "lucide-react";

const statusFilters: { label: string; value: InvoiceStatus | "all" }[] = [
  { label: "All", value: "all" },
  { label: "Pending", value: "pending" },
  { label: "Due soon", value: "due_soon" },
  { label: "Overdue", value: "overdue" },
  { label: "Paid", value: "paid" },
];

const Dashboard = () => {
  const navigate = useNavigate();
  const { invoices } = useInvoices();
  const summary = getDashboardSummary(invoices);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<InvoiceStatus | "all">("all");

  const filteredInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      const matchesFilter = filter === "all" || inv.status === filter;
      const matchesSearch = !search || inv.supplierName.toLowerCase().includes(search.toLowerCase()) || inv.invoiceNumber.toLowerCase().includes(search.toLowerCase());
      return matchesFilter && matchesSearch;
    });
  }, [invoices, search, filter]);

  return (
    <AppLayout>
      <div className="space-y-6 max-w-6xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Invoices</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Manage and track your supplier payments
            </p>
          </div>
          <Button onClick={() => navigate("/upload")} className="gap-2">
            <Upload className="h-4 w-4" />
            Upload invoice
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <SummaryCard
            icon={<Clock className="h-4 w-4" />}
            label="Pending"
            count={summary.totalPending}
            amount={formatCurrency(summary.pendingAmount, "USD")}
            accent="border-l-muted-foreground/40"
          />
          <SummaryCard
            icon={<AlertTriangle className="h-4 w-4" />}
            label="Due soon"
            count={summary.dueSoon}
            amount={formatCurrency(summary.dueSoonAmount, "EUR")}
            accent="border-l-[hsl(var(--status-due-soon-text))]"
          />
          <SummaryCard
            icon={<AlertCircle className="h-4 w-4" />}
            label="Overdue"
            count={summary.overdue}
            amount={formatCurrency(summary.overdueAmount, "EUR")}
            accent="border-l-[hsl(var(--status-overdue-text))]"
          />
          <SummaryCard
            icon={<CheckCircle className="h-4 w-4" />}
            label="Paid"
            count={summary.paid}
            amount={formatCurrency(summary.paidAmount, "GBP")}
            accent="border-l-[hsl(var(--status-paid-text))]"
          />
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search invoices..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 h-9"
            />
          </div>
          <div className="flex items-center gap-1.5">
            {statusFilters.map((sf) => (
              <button
                key={sf.value}
                onClick={() => setFilter(sf.value)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  filter === sf.value
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}
              >
                {sf.label}
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-lg border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Supplier</TableHead>
                <TableHead>Invoice</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>Due date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-10"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInvoices.map((inv) => (
                <TableRow
                  key={inv.id}
                  className="cursor-pointer hover:bg-primary/5 transition-colors"
                  onClick={() => navigate(`/invoice/${inv.id}`)}
                >
                  <TableCell className="font-medium">{inv.supplierName}</TableCell>
                  <TableCell className="text-muted-foreground text-xs font-mono">{inv.invoiceNumber}</TableCell>
                  <TableCell className="text-right font-medium">
                    {formatCurrency(inv.amount, inv.currency)}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {new Date(inv.dueDate).toLocaleDateString("en-US", {
                      month: "short", day: "numeric", year: "numeric",
                    })}
                  </TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadgeVariant(inv.status)}>
                      {getStatusLabel(inv.status)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </TableCell>
                </TableRow>
              ))}
              {filteredInvoices.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                    No invoices found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </AppLayout>
  );
};

const SummaryCard = ({
  icon, label, count, amount, accent,
}: {
  icon: React.ReactNode;
  label: string;
  count: number;
  amount: string;
  accent: string;
}) => (
  <div className={`rounded-lg border border-border bg-card p-4 border-l-4 ${accent}`}>
    <div className="flex items-center gap-2 text-muted-foreground mb-2">
      {icon}
      <span className="text-xs font-medium uppercase tracking-wide">{label}</span>
    </div>
    <p className="text-2xl font-semibold text-foreground">{count}</p>
    <p className="text-xs text-muted-foreground mt-0.5">{amount}</p>
  </div>
);

export default Dashboard;
