import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { CheckCircle, Send } from "lucide-react";
import { useInvoices } from "@/lib/InvoiceContext";

const defaultFields = {
  supplierName: "Luxembourg Industries Ltd.",
  invoiceNumber: "EI268T000084",
  invoiceDate: "2026-03-11",
  dueDate: "2026-09-07",
  currency: "USD",
  amount: "60388.00",
  iban: "IL31 0101 0767 0000 0282 0050",
  bic: "LUMIILITTLV",
};

const ReviewConfirm = () => {
  const navigate = useNavigate();
  const { addInvoice } = useInvoices();
  const [fields, setFields] = useState(defaultFields);

  const update = (key: keyof typeof defaultFields, value: string) => {
    setFields((prev) => ({ ...prev, [key]: value }));
  };

  const saveInvoice = () => {
    return addInvoice({
      supplierName: fields.supplierName,
      invoiceNumber: fields.invoiceNumber,
      amount: parseFloat(fields.amount) || 0,
      currency: fields.currency,
      dueDate: fields.dueDate,
      status: "pending",
      iban: fields.iban,
      bic: fields.bic,
    });
  };

  const handleSave = () => {
    saveInvoice();
    navigate("/dashboard");
  };

  const handleSaveAndPay = () => {
    const id = saveInvoice();
    navigate(`/pay/${id}`);
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-lg space-y-6">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-lg bg-[hsl(var(--status-paid-bg))] flex items-center justify-center mt-0.5">
            <CheckCircle className="h-5 w-5 text-[hsl(var(--status-paid-text))]" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Review extracted data</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Verify the fields below and correct anything that looks wrong
            </p>
          </div>
        </div>

        <div className="rounded-lg border border-border bg-card p-6 space-y-5">
          <Field label="Supplier name" value={fields.supplierName} onChange={(v) => update("supplierName", v)} />
          <Field label="Invoice number" value={fields.invoiceNumber} onChange={(v) => update("invoiceNumber", v)} />
          <Field label="Invoice date" value={fields.invoiceDate} onChange={(v) => update("invoiceDate", v)} type="date" />
          <Field label="Due date" value={fields.dueDate} onChange={(v) => update("dueDate", v)} type="date" />
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">Currency</Label>
              <Select value={fields.currency} onValueChange={(v) => update("currency", v)}>
                <SelectTrigger className="h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Field label="Total amount" value={fields.amount} onChange={(v) => update("amount", v)} />
          </div>
          <Field label="IBAN" value={fields.iban} onChange={(v) => update("iban", v)} />
          <Field label="BIC / SWIFT" value={fields.bic} onChange={(v) => update("bic", v)} />
        </div>

        <div className="flex gap-3">
          <Button variant="outline" className="flex-1 gap-2" onClick={handleSaveAndPay}>
            <Send className="h-4 w-4" />
            Save & pay now
          </Button>
          <Button className="flex-1" onClick={handleSave}>
            Save invoice
          </Button>
        </div>
      </div>
    </AppLayout>
  );
};

const Field = ({
  label, value, onChange, type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) => (
  <div className="space-y-1.5">
    <Label className="text-sm font-medium">{label}</Label>
    <Input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="h-10"
    />
  </div>
);

export default ReviewConfirm;
