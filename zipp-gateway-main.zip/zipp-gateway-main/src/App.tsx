import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { InvoiceProvider } from "@/lib/InvoiceContext";
import Login from "./pages/Login.tsx";
import Dashboard from "./pages/Dashboard.tsx";
import UploadInvoice from "./pages/UploadInvoice.tsx";
import Extracting from "./pages/Extracting.tsx";
import ReviewConfirm from "./pages/ReviewConfirm.tsx";
import InvoiceDetail from "./pages/InvoiceDetail.tsx";
import PayInvoice from "./pages/PayInvoice.tsx";
import PaymentConfirmed from "./pages/PaymentConfirmed.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <InvoiceProvider>
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/upload" element={<UploadInvoice />} />
            <Route path="/extracting" element={<Extracting />} />
            <Route path="/review" element={<ReviewConfirm />} />
            <Route path="/invoice/:id" element={<InvoiceDetail />} />
            <Route path="/pay/:id" element={<PayInvoice />} />
            <Route path="/payment-confirmed/:id" element={<PaymentConfirmed />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </InvoiceProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
